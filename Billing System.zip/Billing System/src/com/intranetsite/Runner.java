package com.intranetsite;

import com.intranetsite.biller.BillGenerator;
import com.intranetsite.utils.Bill;
import com.intranetsite.utils.TimeTracker;

import java.util.Scanner;

public class Runner {
    Bill bill;
    int min = 1;
    int max = 600;
    public Runner(Bill bill){
        this.bill = bill;
    }

    public void executeTask(){
        Scanner scanner = new Scanner(System.in);
        boolean running = true;
        while(running){
            System.out.println("Select an option:\n\t1. Make a call\n\t2. Call other network\n\t3. View bills");
            int choice = scanner.nextInt();
            switch (choice){
                case 1:
                    makeCall(true);
                    break;
                case 2:
                    makeCall(false);
                    break;
                case 3:
                    BillGenerator.generateBill(bill);
                    break;
                default:
                    running = false;
            }
        }
    }
    private void makeCall(boolean timed){
        double charge;
        int randNum = (int) Math.floor(Math.random()*(max-min+1)+min);
        if(timed){
            charge = bill.calcTotalOnNetCharge(randNum, TimeTracker.getIsDayTime());
        }else{
            charge = bill.calcTotalOffNetCharge(randNum);
        }
        System.out.println("Calling...");
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Call ended");
        System.out.printf("Time: %d seconds\nCharge: %.2f\n", randNum, charge);
    }
}
