package com.intranetsite.biller;

import com.intranetsite.utils.Bill;

public class BillGenerator {

    public static void generateBill(Bill bill){
        prettyPrint(bill);
    }
    private static void prettyPrint(Bill bill){
        System.out.println("\tYour bill");
        System.out.println("\t============");
        System.out.println("Billed To:\t" + bill.getName());
        System.out.printf("Total amount:\tKES %.2f\n", bill.getTotalDailyCharge());
        System.out.println("\tYours,\n\tThe Telephone Company\n\n");
    }

}
