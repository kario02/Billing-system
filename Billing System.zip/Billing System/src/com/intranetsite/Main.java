package com.intranetsite;

import com.intranetsite.utils.Bill;

import java.util.Scanner;

public class Main{

    public static void main(String[] args) {
        String name;
        System.out.println("Login by entering your name: ");
        Scanner scanner = new Scanner(System.in);
        name = scanner.nextLine();
        new Runner(new Bill(name)).executeTask();
//        Bill bill = new Bill(name);
//
//        Runner runner = new Runner(bill);
//        runner.executeTask();

    }
}
