package com.intranetsite.utils;

import java.time.LocalTime;

public class TimeTracker {
    private static LocalTime getTimeNow(){
        return LocalTime.now();
    }

    public static boolean getIsDayTime(){
        return getTimeNow().isAfter(LocalTime.parse("05:59:59")) && getTimeNow().isBefore(LocalTime.parse("18:00:01"));
    }
}
