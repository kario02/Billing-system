package com.intranetsite.utils;

public class Bill {
    final private double DAYCHARGE = 4.00;
    final private double NIGHTCHARGE = 3.00;
    final private double OTHERNETWORKCHARGE = 5.00;
    final private double VAT = .16;
    final private int VATABLETIME = 120;
    private double totalNonTaxable = 0;
    private double totalWithTax = 0;
    private double totalWithoutTax = 0;
    private final String name;

    public Bill(String name){
        this.name = name;
    }

    public String getName(){
        return name;
    }

    public double calcTotalOnNetCharge(int duration, boolean isDayTime){
        if(isDayTime){
            return doCalculations(duration, DAYCHARGE);
        }
        return doCalculations(duration, NIGHTCHARGE);

    }

    public double calcTotalOffNetCharge(int duration){
        return doCalculations(duration, OTHERNETWORKCHARGE);
    }

    private double doCalculations(int duration, double charge){
        totalNonTaxable = (charge*duration)/60.0;
        totalWithoutTax += totalNonTaxable;
        if(duration > VATABLETIME){
            totalWithTax += ((totalNonTaxable*VAT));
            return (totalNonTaxable*VAT)+totalNonTaxable;
        }
        return totalNonTaxable;
    }

    public double getTotalDailyCharge(){
        return totalWithTax + totalWithoutTax;
    }
}
